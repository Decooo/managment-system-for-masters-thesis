CREATE PROCEDURE acceptReservation(IN in_idtematu DECIMAL, IN in_iduser DECIMAL)
  begin
Update tematy set status="zajety" where idtematy=in_idtematu;

insert into pracedyplomowe(iduzytkownika,idtematy,praca,status) values(in_iduser,in_idtematu,'','przydzielona');
end;
