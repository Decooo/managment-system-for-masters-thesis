CREATE PROCEDURE rejectReservation(IN in_idtematu DECIMAL)
  begin
Update tematy set status="wolny", iduser=0 where idtematy=in_idtematu;

end;
