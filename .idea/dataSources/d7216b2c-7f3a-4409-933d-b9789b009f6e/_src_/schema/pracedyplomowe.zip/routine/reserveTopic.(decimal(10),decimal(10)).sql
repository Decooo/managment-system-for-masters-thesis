CREATE PROCEDURE reserveTopic(IN in_idtematu DECIMAL, IN in_iduser DECIMAL)
  Begin
Update tematy set status='zarezerwowany', iduser=in_iduser where idtematy=in_idtematu; 
end;
