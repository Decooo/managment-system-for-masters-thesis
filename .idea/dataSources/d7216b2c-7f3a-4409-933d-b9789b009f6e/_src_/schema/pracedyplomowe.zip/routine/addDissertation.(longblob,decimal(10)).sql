CREATE PROCEDURE addDissertation(IN in_praca LONGBLOB, IN in_iduser DECIMAL)
  begin
Update pracedyplomowe set praca=in_praca where iduzytkownika=in_iduser;

end;
