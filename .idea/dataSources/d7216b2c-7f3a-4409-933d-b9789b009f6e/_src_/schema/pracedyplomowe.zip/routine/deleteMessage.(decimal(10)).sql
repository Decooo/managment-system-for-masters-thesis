CREATE PROCEDURE deleteMessage(IN in_idwiadomosci DECIMAL)
  begin 
delete from wiadomosci where idwiadomosci=in_idwiadomosci;
end;
