CREATE PROCEDURE addTopic(IN in_promotor DECIMAL, IN in_temat VARCHAR(255))
  begin
insert into tematy(idpromotora,temat,status,iduser) values (in_promotor,in_temat,'wolny',0);
end;
