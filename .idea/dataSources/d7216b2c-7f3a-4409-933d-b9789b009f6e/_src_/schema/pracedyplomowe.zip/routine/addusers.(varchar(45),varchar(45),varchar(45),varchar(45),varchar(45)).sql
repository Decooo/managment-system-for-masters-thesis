CREATE PROCEDURE addusers(IN in_login    VARCHAR(45), IN in_haslo VARCHAR(45), IN in_imie VARCHAR(45),
                          IN in_nazwisko VARCHAR(45), IN in_rola VARCHAR(45))
  begin
insert into users(login,haslo,imie,nazwisko,rola) values(in_login,in_haslo,in_imie,in_nazwisko,in_rola);
end;
