CREATE PROCEDURE deleteTopic(IN in_idtematu DECIMAL)
  begin 
delete from tematy where idtematy=in_idtematu;
end;
