CREATE PROCEDURE addMessage(IN in_nadawca DECIMAL, IN in_adresat DECIMAL, IN in_temat VARCHAR(255),
                            IN in_tresc   VARCHAR(5000))
  begin
insert into wiadomosci(idnadawcy,idadresata,temat,tresc) values (in_nadawca,in_adresat,in_temat,in_tresc);
end;
